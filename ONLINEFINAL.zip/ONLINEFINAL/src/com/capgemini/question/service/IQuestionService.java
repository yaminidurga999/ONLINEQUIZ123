package com.capgemini.question.service;

import com.capgemini.question.bean.Question;

public interface IQuestionService {
	public Question addQuestion(Question question);
}
